export class Common_Card {
  protected favorite: boolean;
  protected name: string;
  protected prize: number;
  protected amount: number;
  protected product_type: string;
  protected photo: string;

  constructor(
    favorite: boolean,
    name: string,
    prize: number,
    amount: number,
    product_type: string,
    photo: string,
  ) {
    this.favorite = favorite;
    this.name = name;
    this.prize = prize;
    this.amount = amount;
    this.product_type = product_type;
    this.photo = photo;
  }
  favorite_change(favorite: boolean): boolean {
    if (favorite === true) {
      favorite = false;
    }
    if (favorite === false) {
      favorite = true;
    }
    return favorite;
  }
  protected prize_change(amount: number) {
    this.prize = amount;
  }
  protected amount_change(count: number) {
    this.amount = count;
    this.prize_change(this.amount);
  }
  protected amount_add() {
    this.amount++;
    this.prize_change(this.amount);
  }
  protected amount_subtraction() {
    this.amount--;
    this.prize_change(this.amount);
  }
}
export class Food_Card extends Common_Card {
  protected min_kkal: number;
  protected max_kkal: number;
  protected food_type: string;
  constructor(
    min_kkal: number,
    max_kkal: number,
    food_type: string,
    favorite: boolean,
    name: string,
    prize: number,
    amount: number,
    product_type: string,
    photo: string,
  ) {
    super(favorite, name, prize, amount, product_type, photo);
    this.min_kkal = min_kkal;
    this.max_kkal = max_kkal;
    this.food_type = food_type;
  }
}
