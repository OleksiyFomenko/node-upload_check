import { Injectable } from '@nestjs/common';
import { Common_Card, Food_Card } from './cards.dto';

@Injectable()
export class AppService {
  private readonly food_cards: Food_Card[] = [];
  Create_Food_Card(food_card: Food_Card) {
    this.food_cards.push(food_card);
  }

  findAll(): Food_Card[] {
    return this.food_cards;
  }
}
