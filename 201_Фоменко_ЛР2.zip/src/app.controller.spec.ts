import { Test, TestingModule } from '@nestjs/testing';
import { strict } from 'assert';
import { AppController } from './app.controller';
import { AppService } from './app.service';

describe('AppController', () => {});
