import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Delete,
  Param,
} from '@nestjs/common';
import { AppService } from './app.service';
import { Common_Card, Food_Card } from './cards.dto';

@Controller('burger')
export class AppController {
  constructor(private appService: AppService) {}

  @Post()
  async Create_Food_Card(@Body() food_card: Food_Card) {
    this.appService.Create_Food_Card(food_card);
  }

  @Get(':name')
  async findAll(): Promise<Food_Card[]> {
    return this.appService.findAll();
  }

  @Put(':name')
  update(@Param('name') name: string, @Body() food_card: Food_Card) {
    return `This action updates a ${name}`;
  }

  @Delete(':name')
  remove(@Param('name') name: string) {
    return `This action removes a ${name}`;
  }
}
